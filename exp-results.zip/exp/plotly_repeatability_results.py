import subprocess
import os

import argparse
import matplotlib
import json
import numpy as np
import matplotlib.pyplot as plt
import mpl_toolkits.mplot3d.axes3d as axes3d
import math
import pprint
from scipy import stats
from sklearn.metrics import mean_squared_error
from math import sqrt


import plotly.graph_objects as go
import numpy as np


def is_number(s):
    try:
        float(s)
        return True
    except ValueError:
        return False

def KL(a, b):
	#a = np.asarray(a, dtype=np.float)
	#b = np.asarray(b, dtype=np.float)
	
	epsilon = 0.001
	min_size = min(len(a), len(b))
	
	epsilon = 0.001
	a1 = a[0:min_size]
	b1 = b[0:min_size]
	
	return np.sum(np.where(a1 != 0, a1 * np.log((a1 + epsilon) / (b1 + epsilon)), 0))
	#return stats.ks_2samp(a, b)
	

def RMSE(a, b):
	a = np.asarray(a, dtype=np.float)
	b = np.asarray(b, dtype=np.float)
	min_size = min(len(a), len(b))
	
	epsilon = 0.001
	a1 = a[0:min_size]
	b1 = b[0:min_size]
	return np.sqrt(((a1 - b1)**2).mean())

nruns = 1
fat_tree_output = {}
pdfs = {}
KLs = {}
Overheads = {}
Rcts = {}
Rpc_TTFBs = {}

step = 0.01
bins = np.arange(10.0,20.0,step)



exp_types = ["INS_VT", "VT", "BE"]
repeatability_exp = {}
for i in range(1, 4):
	for exp_type in exp_types:
		output_dir = "/home/moses/exp/" + exp_type + "_Fat_Tree_fanout_7_Repeatability_Run" + str(i) + "/worker-2/log/*"
		output = os.popen("grep -nr "  + " \"Transmit Time\" " + output_dir + " | awk \'{print $5}\'").read()
		key = exp_type
		if key not in fat_tree_output:
			fat_tree_output[key] = []
			repeatability_exp[key] = {}
		
		if output  is not None:
			if exp_type == "VT":
				out = [(float(e)*1000.0) + 6.0 for e in output.split('\n') if e  != '']
				fat_tree_output[key].extend(out)
				repeatability_exp[key][i] = [0.0]*len(bins)
				for delay in out :
					idx = int(int(round(delay,1) - 10.0)/step)
					if idx < 0 :
						idx = 0
					if idx > len(bins) - 1 :
						idx = len(bins) - 1
					repeatability_exp[key][i][idx] += 1.0
				repeatability_exp[key][i] = np.array(repeatability_exp[key][i])/len(out)
			else:
				out = [(float(e)*1000.0) for e in output.split('\n') if e  != '']
				fat_tree_output[key].extend(out)
				repeatability_exp[key][i] = [0.0]*len(bins)
				for delay in out :
					idx = int(int(round(delay,1) - 10.0)/step)
					if idx < 0 :
						idx = 0
					if idx > len(bins) - 1 :
						idx = len(bins) - 1
					repeatability_exp[key][i][idx] += 1.0
				repeatability_exp[key][i] = np.array(repeatability_exp[key][i])/len(out)


			
pp = pprint.PrettyPrinter(indent=4)
#pp.pprint(fat_tree_output)
pp.pprint(Overheads)
pp.pprint(Rpc_TTFBs)
fsize=25
markersize = 25.0

sorted_kronos = np.sort(fat_tree_output["INS_VT"])
p_kr = 1. * np.arange(len(sorted_kronos))/(len(sorted_kronos) - 1)

sorted_Tk = np.sort(fat_tree_output["VT"])
p_tk = 1. * np.arange(len(sorted_Tk))/(len(sorted_Tk) - 1)


sorted_BE = np.sort(fat_tree_output["BE"])
p_be = 1. * np.arange(len(sorted_BE))/(len(sorted_BE) - 1)



fig = go.Figure()
fig.add_trace(go.Scatter(
    x=sorted_kronos, y=p_kr,
    name='Kronos',
    mode='lines',
    line=dict(
                color="green",
                width=4.0,
                dash="solid",
            )
))

fig.add_trace(go.Scatter(
    x=sorted_Tk, y=p_tk,
    name='TimeKeeper',
    mode='lines',
    line=dict(
                color="blue",
                width=4.0,
                dash="dash",
            )
))

fig.add_trace(go.Scatter(
    x=sorted_BE, y=p_be,
    name='Best-Effort',
    mode='lines',
    line=dict(
                color="red",
                width=4.0,
                dash="longdash",
            )
))



fig.update_layout(
    title=go.layout.Title(
        text="UDP Request-Response RTT CDF",
	font=dict(
                family="Courier",
                size=30
            ),
	xanchor='center',
        yanchor='top',
	x=0.5,
	y=0.95
    ),
    xaxis=go.layout.XAxis(
        title=go.layout.xaxis.Title(
            text="UDP Request-Response RTT (ms)",
            font=dict(
                family="Courier",
                size=25
            )
        ),
    ),
    yaxis=go.layout.YAxis(
        title=go.layout.yaxis.Title(
            text="Probability",
            font=dict(
                family="Courier",
                size=25
            )
        )
    ),
    legend=go.layout.Legend(
	yanchor='top',
	xanchor='center',
	y=1.1,
	x=0.5,
        font=dict(
            family="sans-serif",
            size=20,
            color="black"
        ),
        #bgcolor="White",
        #bordercolor="Black",
        #borderwidth=5
    )
    
)

fig.update_layout(legend_orientation="h")
fig.update_xaxes(title_font=dict(size=20, family='Courier'), tickfont=dict(family='Courier', size=20), nticks=5)
fig.update_yaxes(title_font=dict(size=20, family='Courier'), tickfont=dict(family='Courier', size=20), range=[0, 1.01])
fig.update_xaxes(ticks="outside", tickwidth=5, ticklen=10)
fig.update_yaxes(ticks="outside", tickwidth=5, ticklen=10)

#fig.show()
fig.write_image("plotly_repeatability.jpg", width=900, height=600)

