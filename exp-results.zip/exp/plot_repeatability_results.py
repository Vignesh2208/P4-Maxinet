import subprocess
import os

import argparse
import matplotlib
import json
import numpy as np
import matplotlib.pyplot as plt
import mpl_toolkits.mplot3d.axes3d as axes3d
import math
import pprint
from scipy import stats
from sklearn.metrics import mean_squared_error
from math import sqrt


def is_number(s):
    try:
        float(s)
        return True
    except ValueError:
        return False

def KL(a, b):
	#a = np.asarray(a, dtype=np.float)
	#b = np.asarray(b, dtype=np.float)
	
	epsilon = 0.001
	min_size = min(len(a), len(b))
	
	epsilon = 0.001
	a1 = a[0:min_size]
	b1 = b[0:min_size]
	
	return np.sum(np.where(a1 != 0, a1 * np.log((a1 + epsilon) / (b1 + epsilon)), 0))
	#return stats.ks_2samp(a, b)
	

def RMSE(a, b):
	a = np.asarray(a, dtype=np.float)
	b = np.asarray(b, dtype=np.float)
	min_size = min(len(a), len(b))
	
	epsilon = 0.001
	a1 = a[0:min_size]
	b1 = b[0:min_size]
	return np.sqrt(((a1 - b1)**2).mean())

nruns = 1
fat_tree_output = {}
pdfs = {}
KLs = {}
Overheads = {}
Rcts = {}
Rpc_TTFBs = {}

step = 0.01
bins = np.arange(10.0,20.0,step)



exp_types = ["INS_VT", "VT", "BE"]
repeatability_exp = {}
for i in xrange(1, 4):
	for exp_type in exp_types:
		output_dir = "/home/moses/exp/" + exp_type + "_Fat_Tree_fanout_7_Repeatability_Run" + str(i) + "/worker-2/log/*"
		output = os.popen("grep -nr "  + " \"Transmit Time\" " + output_dir + " | awk \'{print $5}\'").read()
		key = exp_type
		if key not in fat_tree_output:
			fat_tree_output[key] = []
			repeatability_exp[key] = {}
		
		if output  is not None:
			if exp_type == "VT":
				out = [(float(e)*1000.0) + 6.0 for e in output.split('\n') if e  != '']
				fat_tree_output[key].extend(out)
				repeatability_exp[key][i] = [0.0]*len(bins)
				for delay in out :
					idx = int(int(round(delay,1) - 10.0)/step)
					if idx < 0 :
						idx = 0
					if idx > len(bins) - 1 :
						idx = len(bins) - 1
					repeatability_exp[key][i][idx] += 1.0
				repeatability_exp[key][i] = np.array(repeatability_exp[key][i])/len(out)
			else:
				out = [(float(e)*1000.0) for e in output.split('\n') if e  != '']
				fat_tree_output[key].extend(out)
				repeatability_exp[key][i] = [0.0]*len(bins)
				for delay in out :
					idx = int(int(round(delay,1) - 10.0)/step)
					if idx < 0 :
						idx = 0
					if idx > len(bins) - 1 :
						idx = len(bins) - 1
					repeatability_exp[key][i][idx] += 1.0
				repeatability_exp[key][i] = np.array(repeatability_exp[key][i])/len(out)


			
pp = pprint.PrettyPrinter(indent=4)
#pp.pprint(fat_tree_output)
pp.pprint(Overheads)
pp.pprint(Rpc_TTFBs)
fsize=25
markersize = 25.0


fig = plt.figure(dpi=100)
sorted_kronos = np.sort(fat_tree_output["INS_VT"])
p = 1. * np.arange(len(sorted_kronos))/(len(sorted_kronos) - 1)
plt.plot(sorted_kronos, p, label='Kronos', linestyle=':', linewidth=4)

sorted_Tk = np.sort(fat_tree_output["VT"])
p = 1. * np.arange(len(sorted_Tk))/(len(sorted_Tk) - 1)
plt.plot(sorted_Tk, p, label='TimeKeeper', linestyle='--', linewidth=4)

sorted_BE = np.sort(fat_tree_output["BE"])
p = 1. * np.arange(len(sorted_BE))/(len(sorted_BE) - 1)
plt.plot(sorted_BE, p, label='Best-Effort', linestyle='-.', linewidth=4)
#plt.title("UDP Request-Response repeatability across 3 experiment runs", fontsize=fsize)
plt.xlabel('UDP Request-Response RTT (ms)', fontsize=fsize)
plt.ylabel('Probability', fontsize=fsize)
plt.xticks(fontsize=fsize)
plt.yticks(fontsize=fsize)
#plt.legend()
plt.legend(ncol=3, loc=9, fontsize=fsize, bbox_to_anchor=(0, 1.04, 1, .104))
plt.show()

RMS = {}
KLs = {}
for exp in exp_types:
	key = exp
	RMS[key] = {}
	KLs[key] = {}
	for i in xrange(1,4) :
		RMS[key][i] = {}
		KLs[key][i] = {}
		#if exp == "INS_VT" :
		#	print repeatability_exp[key][i]
		for j in xrange(1,4) :
			#RMS[key][i][j] = RMSE(repeatability_exp[key][i], repeatability_exp[key][j])
			KLs[key][i][j] = KL(repeatability_exp[key][i], repeatability_exp[key][j])
#pp.pprint(repeatability_exp)
print "RMS:"
pp.pprint(RMS)

print "KL:"
pp.pprint(KLs)
