import subprocess
import os

import argparse
import matplotlib
import json
import numpy as np
import matplotlib.pyplot as plt
import mpl_toolkits.mplot3d.axes3d as axes3d
import math
import matplotlib.ticker as mtick
import pprint
from scipy import stats
from sklearn.metrics import mean_squared_error
from math import sqrt


def is_number(s):
    try:
        float(s)
        return True
    except ValueError:
        return False



nruns = 1
fat_tree_output = {}
fat_tree_output["Kronos"] = []
fat_tree_output["BE"] = []
pdfs = {}
KLs = {}
Overheads = {}
Rcts = {}
Rpc_TTFBs = {}

fanouts = [4,5,6,7]


for i in xrange(1,nruns+1):

	output_dir = "/home/moses/exp/INS_VT_Fat_Tree_fanout_5_Run" + str(i) + "/*"
	output = os.popen("grep -nr "  + " \"rpc_duration\" " + output_dir + " | awk \'{print $10}\'").read()
	if output  is not None:
		fat_tree_output["Kronos"].extend([float(e) for e in output.split('\n') if e  != ''])

	output_dir = "/home/moses/exp/BE_Fat_Tree_fanout_5_Run" + str(i) + "/*"
	output = os.popen("grep -nr "  + " \"rpc_duration\" " + output_dir + " | awk \'{print $10}\'").read()
	if output  is not None:
		fat_tree_output["BE"].extend([float(e) for e in output.split('\n') if e  != ''])


for fanout in fanouts:
	for n_workers in xrange(1,4) :
		key = "Kronos_" + str(fanout) +  "_" + str(n_workers)
		fat_tree_output[key] = []
		pdfs[key] = [0.0]*100
		output_dir = "/home/moses/exp/INS_VT_Fat_Tree_fanout_" + str(fanout) + "_" + str(n_workers) + "Workers_Run1/*"
		output = os.popen("grep -nr "  + " \"rpc_duration\" " + output_dir + " | awk \'{print $10}\'").read()
		count = 0.0
		with open("/home/moses/exp/INS_VT_Fat_Tree_fanout_" + str(fanout) + "_" + str(n_workers) + "Workers_Run1/worker-2/log/exp_stats.json") as f:
			data = json.load(f) 
		if fanout == 7 and n_workers == 1 :
			rcts = data["round_completion_times"][1000:]
			rcts = 100.0/(np.sort(rcts)*1000000.0)
			Overheads[key] = (np.mean(rcts), 1.96*np.std(rcts)/math.sqrt(len(rcts)))
			sorted_kronos = np.sort(rcts)#*1000.0
			p = 1. * np.arange(len(sorted_kronos))/(len(sorted_kronos) - 1)
			Rcts[key] = (sorted_kronos, p)
		else :
			rcts = data["round_completion_times"][1000:]
			rcts = 100.0/(np.sort(rcts)*1000000.0)
			Overheads[key] = (np.mean(rcts), 1.96*np.std(rcts)/math.sqrt(len(rcts)))
			#Overheads[key] = (data["mu_rct"], 1.96*data["std_rct"]/math.sqrt(10000))
			sorted_kronos = np.sort(rcts)#*1000.0
			p = 1. * np.arange(len(sorted_kronos))/(len(sorted_kronos) - 1)
			Rcts[key] = (sorted_kronos, p)

		if output  is not None:
			for e in output.split('\n') :
				if e != '':
					fat_tree_output[key].append(float(e))
					if float(e) >= 100.0 :
						pdfs[key][99] += 1.0
					elif float(e) <= 0.0 :
						pdfs[key][0] += 1.0
					else:
						pdfs[key][int(float(e)*1000.0)] += 1.0
					count += 1.0
			if count > 0 :
				pdfs[key] = np.array(pdfs[key])/count

		Rpc_TTFBs[key] = (np.mean(fat_tree_output[key]), 1.96*np.std(fat_tree_output[key])/math.sqrt(len(fat_tree_output[key])))
		

			
pp = pprint.PrettyPrinter(indent=4)
#pp.pprint(fat_tree_output)
pp.pprint(Overheads)
pp.pprint(Rpc_TTFBs)
fsize=25
markersize = 25.0


fig = plt.figure(dpi=100)
kronos_throughput = []
normal_throughput = []

kronos_throughput.extend(fat_tree_output["Kronos"])
normal_throughput.extend(fat_tree_output["BE"])

sorted_kronos = np.sort(kronos_throughput)
p = 1. * np.arange(len(kronos_throughput))/(len(kronos_throughput) - 1)
plt.plot(sorted_kronos, p, label='With Kronos', color='red')

sorted_BE = np.sort(normal_throughput)
p = 1. * np.arange(len(normal_throughput))/(len(normal_throughput) - 1)
plt.plot(sorted_BE, p, label='Best Effort Emulation', color='blue')
plt.xlabel('Time to First Byte (ms)', fontsize=fsize)
plt.ylabel('Probability', fontsize=fsize)
plt.xticks(fontsize=fsize)
plt.yticks(fontsize=fsize)
plt.legend()
plt.show()

fig = plt.figure(dpi=100)
ax = fig.add_subplot(111)
markers = ['*', '^', '>']

def my_formatter(x, pos):
	"""Format 1 as 1, 0 as 0, and all values whose absolute values is between
	0 and 1 without the leading "0." (e.g., 0.7 is formatted as .7 and -0.4 is
	formatted as -.4)."""
	val_str = '{:g}'.format(x)
	if np.abs(x) > 0 and np.abs(x) < 1:
		return val_str.replace("0", "", 1)
	else:
		return val_str

for n_workers in xrange(1,4) :
	overhead_mu = [Overheads["Kronos_" + str(fanout) + "_" + str(n_workers)][0] for fanout in fanouts]
	overhead_std = [Overheads["Kronos_" + str(fanout) + "_" + str(n_workers)][1] for fanout in fanouts]
	ax.errorbar(x =fanouts, y = overhead_mu, yerr= overhead_std, marker = markers[n_workers-1], label = str(n_workers) + " Workers",fmt='o',markersize=markersize)
plt.xlim([3,8])
plt.xlabel('Fat Tree Topology Fanout', fontsize=fsize)
#f = mtick.ScalarFormatter(useOffset=False, useMathText=True)
#g = lambda x,pos : "${}$".format(f._formatSciNotation('%1.10e' % x))
ax.yaxis.set_major_formatter(mtick.FuncFormatter(my_formatter))

#ax.tick_params(axis="y",direction="in", pad = -100)
ax.yaxis.tick_right()
#ax.yaxis.set_major_formatter(mtick.FormatStrFormatter('%.1e'))
plt.ylabel('Virtual Time advance (per sec)', fontsize=fsize)
#plt.title('Emulation Speed in distributed mode', fontsize=fsize)
plt.legend(ncol=3, loc=9, fontsize=fsize, bbox_to_anchor=(0, 1.04, 1, .104))
plt.xticks(fontsize=fsize)
plt.yticks(fontsize=fsize)
#plt.legend(loc='upper center')
plt.show()

fig = plt.figure(dpi=100)
ax = fig.add_subplot(111)
markers = ['*', '^', '>']

for n_workers in xrange(1,4) :
	rpc_mu = [Rpc_TTFBs["Kronos_" + str(fanout) + "_" + str(n_workers)][0]*1000.0 for fanout in fanouts]
	rpc_std = [Rpc_TTFBs["Kronos_" + str(fanout) + "_" + str(n_workers)][1]*1000.0 for fanout in fanouts]
	ax.errorbar(x =fanouts, y = rpc_mu, yerr= rpc_std, marker = markers[n_workers-1], label = str(n_workers) + " Workers",fmt='o',markersize=markersize)
plt.xlim([3,8])
plt.ylim([0,50])
plt.xlabel('Fat Tree Topology Fanout', fontsize=fsize)
plt.ylabel('RPC Time to First Byte (ms)', fontsize=fsize)
#plt.title('RPC Time To First Byte in distributed mode', fontsize=fsize)
plt.legend(ncol=3, loc=9, fontsize=fsize, bbox_to_anchor=(0, 1.04, 1, .104))
plt.xticks(fontsize=fsize)
plt.yticks(fontsize=fsize)
#plt.legend(loc='best')
plt.show()


fig = plt.figure(dpi=100)
ax = fig.add_subplot(111)
linestyles = [":", "-.", "--"]
for n_workers in xrange(1,4) :
	rct_s = Rcts["Kronos_7" + "_" + str(n_workers)][0]
	rct_p = Rcts["Kronos_7" + "_" + str(n_workers)][1]
	ax.plot(rct_s,rct_p, linestyle = linestyles[n_workers-1], label = str(n_workers) + " Workers")
ax.set_xscale('log')

plt.xlabel('Round Completion Times (ms)', fontsize=fsize)
plt.ylabel('Probability', fontsize=fsize)
plt.title("Fat Tree Topology (Fanout=7)", fontsize=fsize)
plt.legend(loc='best')
#plt.show()

