import subprocess
import os

import argparse
import matplotlib
import json
import numpy as np
import matplotlib.pyplot as plt
import mpl_toolkits.mplot3d.axes3d as axes3d
import math
import pprint
from scipy import stats
from sklearn.metrics import mean_squared_error
from math import sqrt


def is_number(s):
    try:
        float(s)
        return True
    except ValueError:
        return False

	

def RMSE(a, b):
	a = np.asarray(a, dtype=np.float)
	b = np.asarray(b, dtype=np.float)
	min_size = min(len(a), len(b))
	
	epsilon = 0.001
	a1 = a[0:min_size]
	b1 = b[0:min_size]
	return np.sqrt(((a1 - b1)**2).mean())



exp_types = ["INS_VT", "VT", "BE"]
repeatability_exp = {}
for i in xrange(1, 4):
	for exp_type in exp_types:
		output_dir = "/home/moses/exp/" + exp_type + "_Fat_Tree_fanout_7_Repeatability_Run" + str(i) + "/worker-2/log/hh17.log"
		output = os.popen("grep -nr "  + " \"Recv Time:\" " + output_dir + " | awk \'{print $8}\'").read()
		key = exp_type
		if key not in repeatability_exp:
			repeatability_exp[key] = {}
		
		if output  is not None:
			
			out = [float(e) for e in output.split('\n') if e  != '']
			repeatability_exp[key][i] = [0.0]*50
			j = 0			
			for ts in out :
				if j > 0 :
					repeatability_exp[key][i][j] = ts - out[0]
				if j >= 49 :
					break
				j += 1

RMS = {}
for exp in exp_types:
	key = exp
	RMS[key] = {}
	for i in xrange(1,4) :
		RMS[key][i] = {}
		for j in xrange(1,4) :
			RMS[key][i][j] = RMSE(repeatability_exp[key][i], repeatability_exp[key][j])

pp = pprint.PrettyPrinter(indent=4)

print "RMS Errors:"
pp.pprint(RMS)

