import subprocess
import os

import argparse
import matplotlib
import json
import numpy as np
import matplotlib.pyplot as plt
import mpl_toolkits.mplot3d.axes3d as axes3d
import math
import pprint

import plotly.graph_objects as go
import numpy as np

def is_number(s):
    try:
        float(s)
        return True
    except ValueError:
        return False



speeds = [25,50,100,200]
nruns = 1
star_output = {}
star_output["Kronos"] = {}
star_output["BE"] = []


for speed in speeds:

	output_dir = "/home/moses/exp/INS_VT_Star_1sw_64hosts_Speed" + str(speed) + "/*"
	output = os.popen("grep -nr "  + " \"Mbits/sec\" " + output_dir + " | awk \'{print $8}\'").read()
	if output  is not None:
		if speed not in star_output["Kronos"]:
			star_output["Kronos"][speed] = []		
		star_output["Kronos"][speed].extend(
				[float(e) for e in output.split('\n') if e  != ''])

output_dir = "/home/moses/exp/BE_Star_1sw_64hosts/*"
output = os.popen("grep -nr "  + " \"Mbits/sec\" " + output_dir + " | awk \'{print $8}\'").read()
if output  is not None:
	star_output["BE"].extend([float(e) for e in output.split('\n') if e  != ''])


			
pp = pprint.PrettyPrinter(indent=4)
#pp.pprint(star_output)
fsize=20
markersize = 15.0

fig = plt.figure(dpi=100)
ax = fig.add_subplot(111)
avg_kronos_switch_throughput = [32*np.mean(star_output["Kronos"][speed])/1000.0 for speed in speeds]
std_kronos_switch_throughput = [np.std(star_output["Kronos"][speed])/1000.0 for speed in speeds ]

fsize=25
markersize = 25.0


"""
fig = go.Figure()
fig.add_trace(go.Scatter(
    x=speeds, y=avg_kronos_switch_throughput,
    mode='markers',
    error_y=dict(type='data', array=std_kronos_switch_throughput, thickness=1.5, width=3),
    marker=dict(color='purple', size=20, symbol='triangle-up-dot')
))

fig.update_layout(
    title=go.layout.Title(
        text="BMv2 Switch in a Star Topology with 64 Hosts",
	font=dict(
                family="Courier",
                size=30
            ),
	xanchor='center',
        yanchor='top',
	x=0.5,
	y=0.95
    ),
    xaxis=go.layout.XAxis(
        title=go.layout.xaxis.Title(
            text="Relative CPU speed of P4 Switch [units]",
            font=dict(
                family="Courier",
                size=25
            )
        ),
    ),
    yaxis=go.layout.YAxis(
        title=go.layout.yaxis.Title(
            text="Cumulative Switch Throughput [Gbps]",
            font=dict(
                family="Courier",
                size=25
            )
        )
    )
    
)


fig.update_xaxes(title_font=dict(size=20, family='Courier'), tickfont=dict(family='Courier', size=20), nticks=5)
fig.update_yaxes(title_font=dict(size=20, family='Courier'), tickfont=dict(family='Courier', size=20))
fig.update_xaxes(ticks="outside", tickwidth=5, ticklen=10)
fig.update_yaxes(ticks="outside", tickwidth=5, ticklen=10)

#fig.show()
fig.write_image("plotly_cumulative_throughput.jpg", width=900, height=600)
"""





fig = plt.figure(dpi=100)

normal_throughput = []

normal_throughput.extend(star_output["BE"])

linestyles = ["solid", "dot", "dash", "longdash"]
colors = ["red", "blue", "green", "orange"]

i = 0
fig = go.Figure()
for speed in speeds:
	kronos_throughput = []
	kronos_throughput.extend(star_output["Kronos"][speed])
	sorted_kronos = np.sort(kronos_throughput)
	p = 1. * np.arange(len(kronos_throughput))/(len(kronos_throughput) - 1)
	fig.add_trace(go.Scatter(
	    x=sorted_kronos, y=p,
	    name='Kronos R-CPU Speed=' + str(speed),
	    mode='lines',
	    line=dict(
                color=colors[i],
                width=4.0,
                dash=linestyles[i],
            )
	))
	i += 1

sorted_BE = np.sort(normal_throughput)
p = 1. * np.arange(len(normal_throughput))/(len(normal_throughput) - 1)

fig.add_trace(go.Scatter(
	    x=sorted_BE, y=p,
	    name='Best Effort',
	    mode='lines',
	    line=dict(
                color="black",
                width=4.0,
                dash="longdashdot",
            )
	))


fig.update_layout(
    title=go.layout.Title(
        text="CDF of BMv2 Switch Data Transfer rate across all flows",
	font=dict(
                family="Courier",
                size=30
            ),
	xanchor='center',
        yanchor='top',
	x=0.5,
	y=1.0
    ),
    xaxis=go.layout.XAxis(
        title=go.layout.xaxis.Title(
            text="Observed throughput for each flow (Mbits/sec)",
            font=dict(
                family="Courier",
                size=25
            )
        ),
    ),
    yaxis=go.layout.YAxis(
        title=go.layout.yaxis.Title(
            text="Probability",
            font=dict(
                family="Courier",
                size=25
            )
        )
    ),
    legend=go.layout.Legend(
	yanchor='top',
	xanchor='center',
	y=1.13,
	x=0.5,
        font=dict(
            family="sans-serif",
            size=20,
            color="black"
        ),
        #bgcolor="White",
        #bordercolor="Black",
        #borderwidth=5
    )
    
)

fig.update_layout(legend_orientation="h")
fig.update_xaxes(title_font=dict(size=20, family='Courier'), tickfont=dict(family='Courier', size=20), nticks=5, range=[0, 600])
fig.update_yaxes(title_font=dict(size=20, family='Courier'), tickfont=dict(family='Courier', size=20), range=[0, 1.01])
fig.update_xaxes(ticks="outside", tickwidth=5, ticklen=10)
fig.update_yaxes(ticks="outside", tickwidth=5, ticklen=10)

#fig.show()
fig.write_image("plotly_per_flow_throughput.jpg", width=1100, height=700)



