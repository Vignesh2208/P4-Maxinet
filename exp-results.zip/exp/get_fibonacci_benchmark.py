import subprocess
import os

import argparse
import matplotlib
import json
import numpy as np
import matplotlib.pyplot as plt
import mpl_toolkits.mplot3d.axes3d as axes3d
import math
import pprint
from scipy import stats
from sklearn.metrics import mean_squared_error
from math import sqrt


def is_number(s):
    try:
        float(s)
        return True
    except ValueError:
        return False

	



exp_types = ["Kronos", "TK", "BE"]
repeatability_exp = {}
for j in xrange(1, 6):
	for exp_type in exp_types:
		output_dir = "/home/moses/exp/" + exp_type + "_Repeatability_Benchmark_Run" + str(j) + "/worker-2/log/*"
		start_output = os.popen("grep -nr "  + " \"Start Time (sec) :\" " + output_dir + " | awk \'{print $5}\'").read()
		end_output = os.popen("grep -nr "  + " \"Start Time (sec) :\" " + output_dir + " | awk \'{print $9}\'").read()
		key = exp_type
		if key not in repeatability_exp:
			repeatability_exp[key] = {}
			repeatability_exp[key]["start"] = []
			repeatability_exp[key]["end"] = []
			repeatability_exp[key]["elapsed"] = []
		
		if start_output  is not None:
			
			out = [float(e[:-1]) for e in start_output.split('\n') if e  != '']
			repeatability_exp[key]["start"].extend(out)
						
		if end_output  is not None:
			if exp_type != "Kronos" :
				out = [float(e[:-1]) for e in end_output.split('\n') if e  != '']
			else :
				out = [float(e) for e in end_output.split('\n') if e  != '']
			repeatability_exp[key]["end"].extend(out)
		for i in xrange(0, len(repeatability_exp[key]["end"])) :
			repeatability_exp[key]["elapsed"].append(repeatability_exp[key]["end"][i] - repeatability_exp[key]["start"][i])

print "Kronos (Mu, Std): ", np.mean(np.array(repeatability_exp["Kronos"]["elapsed"])), np.std(np.array(repeatability_exp["Kronos"]["elapsed"]))

print "TimeKeeper (Mu, Std): ", np.mean(np.array(repeatability_exp["TK"]["elapsed"])), np.std(np.array(repeatability_exp["TK"]["elapsed"]))

print "BE (Mu, Std): ", np.mean(np.array(repeatability_exp["BE"]["elapsed"])), np.std(np.array(repeatability_exp["BE"]["elapsed"]))
						
