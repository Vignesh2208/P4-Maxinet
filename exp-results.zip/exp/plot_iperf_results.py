import subprocess
import os

import argparse
import matplotlib
import json
import numpy as np
import matplotlib.pyplot as plt
import mpl_toolkits.mplot3d.axes3d as axes3d
import math
import pprint

def is_number(s):
    try:
        float(s)
        return True
    except ValueError:
        return False


ring_sizes = [10,20,30,40,50]
nruns = 3

iperf_output = {}
iperf_output["Kronos"] = {}
iperf_output["BE"] = {}

for size in ring_sizes:
	for i in xrange(1,nruns+1):
		if i == 0 :
			output_dir = "/home/moses/exp/INS_VT_Ring_Iperf_" + str(size) + "sw_" + str(size) + "hosts/*" 
		else:
			output_dir = "/home/moses/exp/INS_VT_Ring_Iperf_" + str(size) + "sw_" + str(size) + "hosts_Run" + str(i) + "/*"
		output = os.popen("grep -nr "  + " \"Mbits/sec\" " + output_dir + " | awk \'{print $8}\'").read()
		if output  is not None:
			if size not in iperf_output["Kronos"] :
				iperf_output["Kronos"][size] = []
			iperf_output["Kronos"][size].extend([int(e) for e in output.split('\n') if e  != ''])
		#print "Size = ", size, " Run = ", i, output

for size in ring_sizes:
	for i in xrange(1,nruns+1):
		if i == 0 :
			output_dir = "/home/moses/exp/BE_Ring_Iper_" + str(size) + "sw_" + str(size) + "hosts/*" 
		else:
			output_dir = "/home/moses/exp/BE_Ring_Iper_" + str(size) + "sw_" + str(size) + "hosts_Run" + str(i) + "/*"
		output = os.popen("grep -nr "  + " \"Mbits/sec\" " + output_dir + " | awk \'{print $8}\'").read()
		
		if output  is not None:
			if size not in iperf_output["BE"] :
				iperf_output["BE"][size] = []
			iperf_output["BE"][size].extend([int(float(e)) for e in output.split('\n') if is_number(e)  != False])
			
pp = pprint.PrettyPrinter(indent=4)

fig = plt.figure(dpi=100)
ax = fig.add_subplot(111)
pp.pprint(iperf_output["BE"])
avg_kronos_throughput = [np.mean(iperf_output["Kronos"][size]) for size in ring_sizes ]
std_kronos_throughput = [np.std(iperf_output["Kronos"][size]) for size in ring_sizes ]

avg_BE_throughput = [np.mean(iperf_output["BE"][size]) for size in ring_sizes ]
std_BE_throughput = [np.std(iperf_output["BE"][size]) for size in ring_sizes ]

fsize=28
markersize = 25.0

ax.errorbar(x =ring_sizes, y = avg_kronos_throughput, yerr= std_kronos_throughput, marker = '^', label = "Kronos",fmt='o',markersize=markersize)
ax.errorbar(x =ring_sizes, y = avg_BE_throughput, yerr= std_BE_throughput, marker = '^', label = "Best-Effort Emulation",fmt='o',markersize=markersize)
#ax.set_title("Iperf Data Transfer with non-interfering flows", fontsize=fsize)
ax.set_xlabel("Size of Ring Topology", fontsize=fsize)
ax.set_ylabel("Data Transfer Rate (Mbits/sec)", fontsize=fsize)
ax.legend(ncol=4, loc=9, fontsize=fsize, bbox_to_anchor=(0, 1.03, 1, .103))
#plt.legend(loc='best')
ax.set_xlim([0,60])
plt.xticks(fontsize=fsize)
plt.yticks(fontsize=fsize)
plt.show()

fig = plt.figure(dpi=100)
kronos_throughput = []
normal_throughput = []
for size in ring_sizes:
	kronos_throughput.extend(iperf_output["Kronos"][size])
	normal_throughput.extend(iperf_output["BE"][size])

sorted_kronos = np.sort(kronos_throughput)
p = 1. * np.arange(len(kronos_throughput))/(len(kronos_throughput) - 1)
plt.plot(sorted_kronos, p, label='Kronos', color='red', linestyle='--', linewidth=4)

sorted_BE = np.sort(normal_throughput)
p = 1. * np.arange(len(normal_throughput))/(len(normal_throughput) - 1)
plt.plot(sorted_BE, p, label='Best-Effort Emulation', color='blue', linestyle='-.',linewidth=4)

#plt.title("Iperf Data Transfer with non-interfering flows", fontsize=fsize)
plt.xlabel('Data Transfer Rate (Mbits/sec)', fontsize=fsize)
plt.ylabel('Probability', fontsize=fsize)
plt.xticks(fontsize=fsize)
plt.yticks(fontsize=fsize)
plt.legend(ncol=4, loc=9, fontsize=fsize, bbox_to_anchor=(0, 1.03, 1, .103))
#plt.legend()

plt.show()
