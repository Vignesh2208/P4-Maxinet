import subprocess
import os

import argparse
import matplotlib
import json
import numpy as np
import matplotlib.pyplot as plt
import mpl_toolkits.mplot3d.axes3d as axes3d
import math
import pprint
from scipy import stats

fanout = 7

def conf_95(arr):
	return 1.96*np.std(arr)/math.sqrt(len(arr))

with open("/home/moses/exp/INS_VT_Fat_Tree_fanout_" + str(fanout) + "_2" + "Workers_Overhead_Stats/worker-2/log/exp_stats.json") as f:
	exp_stats_2 = json.load(f)

with open("/home/moses/exp/INS_VT_Fat_Tree_fanout_" + str(fanout) + "_3" + "Workers_Overhead_Stats/worker-2/log/exp_stats.json") as f:
	exp_stats_3 = json.load(f)


with open("/home/moses/exp/INS_VT_Fat_Tree_fanout_" + str(fanout) + "_2" + "Workers_Overhead_Stats/worker-2/log/overhead_stats.json") as f:
	overhead_stats_2 = json.load(f)

with open("/home/moses/exp/INS_VT_Fat_Tree_fanout_" + str(fanout) + "_3" + "Workers_Overhead_Stats/worker-2/log/overhead_stats.json") as f:
	overhead_stats_3 = json.load(f)

sync_overhead_2 = []
sync_overhead_3 = []
straggler_2 = []

straggling_worker_id_2 = []
straggling_worker_id_3 = []

wait_overhead_2 = []
wait_overhead_3 = []
straggler_3 = []

speed_2 = []
speed_3 = []

n_rounds = len(exp_stats_2["round_completion_times"])

for i in xrange(0, n_rounds) :
	straggling_worker = max(overhead_stats_2["worker-1"]["useful_work_time"][i], overhead_stats_2["worker-2"]["useful_work_time"][i])
	sync_overhead_2.append(exp_stats_2["round_completion_times"][i] - straggling_worker)

	straggling_worker_id_2.append(np.argmax([overhead_stats_2["worker-1"]["useful_work_time"][i], overhead_stats_2["worker-2"]["useful_work_time"][i]]) + 1)

	if i >= 1000 :
		straggler_2.append(straggling_worker)

	wait_overhead_2.append(max(overhead_stats_2["worker-1"]["round_end_time"][i], overhead_stats_2["worker-2"]["round_end_time"][i]) - min(overhead_stats_2["worker-1"]["round_end_time"][i], overhead_stats_2["worker-2"]["round_end_time"][i]))

	straggling_worker = max(overhead_stats_3["worker-1"]["useful_work_time"][i], overhead_stats_3["worker-2"]["useful_work_time"][i], overhead_stats_3["worker-2"]["useful_work_time"][i])
	sync_overhead_3.append(exp_stats_3["round_completion_times"][i] - straggling_worker)

	wait_overhead_3.append(max(overhead_stats_3["worker-1"]["round_end_time"][i], overhead_stats_3["worker-2"]["round_end_time"][i], overhead_stats_3["worker-3"]["round_end_time"][i]) - min(overhead_stats_3["worker-1"]["round_end_time"][i], overhead_stats_3["worker-2"]["round_end_time"][i], overhead_stats_3["worker-1"]["round_end_time"][i]))

	straggling_worker_id_3.append(np.argmax([overhead_stats_3["worker-1"]["useful_work_time"][i], overhead_stats_3["worker-2"]["useful_work_time"][i], overhead_stats_3["worker-3"]["useful_work_time"][i]]) + 1)

	if i >= 1000 :
		straggler_3.append(straggling_worker)


speed_2 = exp_stats_2["round_completion_times"][1000:]
speed_2 = 100.0/(np.sort(speed_2)*1000000.0)
speed_3 = exp_stats_3["round_completion_times"][1000:]
speed_3 = 100.0/(np.sort(speed_3)*1000000.0)

print "Mu,std emulation speed 2 workers ", np.mean(speed_2), conf_95(speed_2)
print "Mu,std emulation speed 3 workers ", np.mean(speed_3), conf_95(speed_3)


print "Mu,std sync overhead time: 2 workers ", np.mean(sync_overhead_2), conf_95(sync_overhead_2)
print "Mu,std sync overhead time: 3 workers ", np.mean(sync_overhead_3), conf_95(sync_overhead_3)

print "Mu,std wait overhead time: 2 workers ", np.mean(wait_overhead_2), conf_95(wait_overhead_2)
print "Mu,std wait overhead time: 3 workers ", np.mean(wait_overhead_3), conf_95(wait_overhead_3)

print "Mu,std straggler time: 2 workers ", np.mean(straggler_2), conf_95(straggler_2)
print "Mu,std straggler time: 3 workers ", np.mean(straggler_3), conf_95(straggler_3)

fig = plt.figure(dpi=100)
plt.title("Straggling Workers in 2 Worker case")
plt.hist(straggling_worker_id_2, bins=[1,2,3])
plt.ylabel("Number of rounds in which worker straggled")
plt.xlabel("Straggling worker label")
plt.show()

fig = plt.figure(dpi=100)
plt.title("Straggling Workers in 3 Worker case")
plt.hist(straggling_worker_id_3, bins = [1,2,3,4])
plt.ylabel("Number of rounds in which worker straggled")
plt.xlabel("Straggling worker label")
plt.show()
